import NavbarOperations from "../../../Components/Organisms/navbar_ops/navbar_ops";
import PersonDetails from "../../../Components/Organisms/personal_detail/personal_details";
import Menubar from "../Menubar/menubar";
import "./header.scss";
import { useNavigate, Link,useLocation } from "react-router-dom";
const Header = () => {

  const location = useLocation();
  const shouldRenderNavbarOps = !(
    location.pathname === '/' || 
    location.pathname === '/login' || 
    location.pathname === '/register'
  );
  const shouldRenderPersonDetails = !(
    location.pathname === '/' || 
    location.pathname === '/login' || 
    location.pathname === '/register'
  );
  return (
    <div className="header-wrapper">
      {/* Parent Class */}
      <div className="header">
        {/* Children Class */}
        <div className="header-text">
          {/* Grand Children Class */}
          <a className="header-links " href="/login">
            <div><Link to="/login">Personal</Link></div>
          </a>
          
          <a className="header-links" href="">
            <div><Link to="/login">Admin</Link></div>
          </a>
        </div>
        <button onClick={"/register"} className="create-account-button">
          <Link to="/register">Create Account / Register</Link>
        </button>
      </div>
      <Menubar />
      {shouldRenderPersonDetails && <PersonDetails />}
     
      {shouldRenderNavbarOps && <NavbarOperations />}
    </div>

  );
};
export default Header;
